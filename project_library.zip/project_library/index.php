<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Library Project</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>
    <div class="main-body">
        <div class="slider">
            <header>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 d-flex justify-content-between">
                            <div class="logo">
                                <a href="index.php">
                                    <img src="assets/images/logo.png" alt="Logo">
                                </a>
                            </div>
                            <nav>
                                <ul>
                                    <li><a href="index.php" class="active">Home</a></li>
                                    <li><a href="#">Contact</a></li>
                                    <li><a href="student-login.php" class="appointment">Book Issue</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </header>
            <section class="login">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 login-tab-section">
                            <div class="col-lg-2"></div>
                            <div class="col-lg-4">
                                <div class="login-tab">
                                    <div class="login-tab-img">
                                        <img src="assets/images/grid-img1.png">
                                    </div>
                                    <div class="login-tab-text">
                                        <h3>Student</h3>
                                        <p>Login</p>
                                        <a href="student-login.php">Click Here</a>
                                    </div>
                                </div>
                            </div>                            
                            <div class="col-lg-4">
                                <div class="login-tab">
                                    <div class="login-tab-img">
                                        <img src="assets/images/grid-img1.png">
                                    </div>
                                    <div class="login-tab-text">
                                        <h3>Student</h3>
                                        <p>Registration</p>
                                        <a href="student-registration.php">Click Here</a>
                                    </div>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</body>

</html>
<!-- <div class="copyright">
    &copy; <span class="current-year">2020</span>
    <span class="text-bold text-uppercase"> HMSP</span>. 
    <span>All rights reserved</span>
</div> -->