<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Library Project</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/main.css">
</head>
<body class="animated-banner">
<div class="main-body">
    <div class="slider parallax" id="banner-animation">
        <header>
			<div class="container">
				<div class="row">
					<div class="col-lg-12 d-flex justify-content-between">
						<div class="logo">
							<a href="index.php">
		                        <img src="assets/images/logo.png"alt="Logo">
		                    </a>
						</div>
						<nav>
							<ul>
								<li><a href="index.php" class="active">Home</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</header>
		<section class="login">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 login-form-section">
						<div class="box-login">
							<h2 class="text-center"> LMS | Student Login</h2>
							<form class="form-login" method="post">
								<fieldset>
									<legend>Sign in to your account</legend>
									<p>Please enter your name and password to log in.<br/></p>
									<div class="form-group">
										<span class="input-icon">
											<input type="text" class="form-control" name="username" placeholder="Username">
											<i class="fa fa-user"></i>
										 </span>
									</div>
									<div class="form-group form-actions">
										<span class="input-icon">
											<input type="password" class="form-control password" name="password" placeholder="Password">
											<i class="fa fa-lock"></i>
										</span>
									</div>
									<div class="form-actions">
										
										<button type="submit" class="btn pull-right" name="submit">
											Login <i class="fa fa-arrow-circle-right"></i>
										</button>
									</div>
									<div class="new-account">
										<p>Don't have an account yet?</p>
										<a href="student-registration.php">
											Create an account
										</a>
									</div>
								</fieldset>
							</form>
							<div class="copyright">
								&copy; <span class="current-year"><?php echo date("Y");?></span><span class="text-bold text-uppercase"> LMS</span>. <span>All rights reserved</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
    </div>
</div>





<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/particles.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>