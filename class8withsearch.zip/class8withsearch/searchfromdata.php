<?php

include_once( 'config.php' );
$action = $_POST['action'] ?? '';
$connection = mysqli_connect( DB_SERVER, DB_USER, DB_PASS, DB_NAME );
if (!$connection) {
    throw new Exception( "Cannot connect to database" );
}else {
    if('search'==$action){
        $search = $_POST['search']??'';
        if($search){
        $query = " SELECT * FROM `userdata` WHERE `email` LIKE '{$search}%' ORDER BY `email`";
        $result = mysqli_query($connection,$query);
        ?>

<?php if(!$result || mysqli_num_rows($result)==0){ ?>
<p>No Search Result found</p>
<?php }else{ ?>

<table>
    <thead>
        <tr>
            <th class="center">ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Website</th>
            <th>Comment</th>
            <th>Gender</th>
            <th>Creation Date</th>
            <th>Update Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php 
    // $data = mysqli_fetch_assoc($result)
        while ($data = mysqli_fetch_assoc($result)) {
    ?>
    <tr>
        <td><?php echo $data['id'];?></td>
        <td><?php echo $data['name'];?></td>
        <td><?php echo $data['email'];?></td>
        <td><?php echo $data['website'];?></td>
        <td><?php echo $data['comment'];?></td>
        <td><?php echo $data['gender'];?></td>
        <td><?php echo $data['creationDate'];?></td>
        <td><?php echo $data['updateDate'];?></td>
        <td><a class="update" href="DeleteUpdate.php">Update</a>|<a class="delete" href="DeleteUpdate.php">Delete</a></td>
    </tr>
    <?php
        }
        mysqli_close($connection);
    ?>
    </tbody>
</table>




        <?php
}
        }
    }

}